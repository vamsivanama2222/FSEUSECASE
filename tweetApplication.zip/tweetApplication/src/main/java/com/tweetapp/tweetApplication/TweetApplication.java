package com.tweetapp.tweetApplication;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.data.mongo.MongoDataAutoConfiguration;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.tweetapp.tweetApplication.repo.TweetApplicationRepository;

@SpringBootApplication(exclude={MongoAutoConfiguration.class, MongoDataAutoConfiguration.class})
public class TweetApplication implements CommandLineRunner {
	@Autowired
	TweetApplicationRepository tweetRepo;
	@Autowired
	MongoTemplate template;
	
	@Autowired 
	MongoOperations mongoOperations;
	

	@Override
	public void run(String... args) throws Exception {
	

		
		/*
		 * tweetRepo.deleteAll();
		 * 
		 * ----> To add dummy user
		 * User user1=new User("changes",
		 * "hsddjiww","Fd","abcd@gmail.com","password","12324355",null,null);
		 * 
		 * tweetRepo.save(user1); // initial List Companies variable List<User>
		 * 

		 */
		/*
		 * User user3=new User("Firster",
		 * "LastNameer","Fd","abcdef@gmail.com","password","12324355",null,null);
		 * 
		 * tweetRepo.save(user3);
		 */
		

	}
		
		 
		
	public static void main(String[] args) {
		SpringApplication.run(TweetApplication.class, args);
	}

}
