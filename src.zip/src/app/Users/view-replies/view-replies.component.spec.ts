import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewRepliesComponent } from './view-replies.component';

describe('ViewRepliesComponent', () => {
  let component: ViewRepliesComponent;
  let fixture: ComponentFixture<ViewRepliesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewRepliesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewRepliesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
