export class User {
   public id: string;
   public username: string;
   public email:string;
   public password: string;
   public firstName: string;
   public lastName: string;
   public phone: string;
   public tweeta:any[];
   public replies:any[];

}